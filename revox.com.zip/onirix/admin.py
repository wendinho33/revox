from django.contrib import admin
from onirix.models import Contact_US, Newsletter, Payments
# Register your models here.

admin.site.register(Contact_US)
admin.site.register(Newsletter)
admin.site.register(Payments)